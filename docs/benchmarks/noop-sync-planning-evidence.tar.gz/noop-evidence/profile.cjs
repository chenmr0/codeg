const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),cp=require('node:child_process');
const checkout=process.argv[2];
(async()=>{
 const {CodeGraph}=require(path.join(checkout,'dist'));
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'noop-profile-'));
 fs.mkdirSync(path.join(root,'src'));
 cp.execFileSync('git',['init','-q'],{cwd:root});
 for(let i=0;i<1000;i++)fs.writeFileSync(path.join(root,'src',i+'.c'),`int func_${i}(void){return ${i};}\n`);
 cp.execFileSync('git',['add','.'],{cwd:root});
 let graph=await CodeGraph.init(root,{index:true});
 fs.writeFileSync(path.join(root,'tracked.json'),JSON.stringify(graph.getFiles()));
 await graph.whenIdle();graph.close();await graph.whenIdle();
 const code=`const fs=require('fs'),path=require('path');const {performance}=require('perf_hooks');const p=require(${JSON.stringify(path.join(checkout,'dist/sync/adaptive-plan'))});const root=${JSON.stringify(root)};const tracked=JSON.parse(fs.readFileSync(path.join(root,'tracked.json')));(async()=>{const t=performance.now();const runtime=p.adaptiveRuntimeKey(root,'node-sqlite');const r=performance.now();const plan=await p.createAdaptivePlan(root,tracked,{runtimeKey:runtime});console.log(JSON.stringify({runtimeMs:r-t,planMs:performance.now()-r,changed:plan.changedFiles,files:plan.totalFiles}));})();`;
 console.log('cold planning components:',cp.execFileSync(process.execPath,['--liftoff-only','-e',code],{encoding:'utf8'}));
 graph=CodeGraph.openSync(root);let decisions=[];let t=performance.now();let result=await graph.sync({onAdaptiveDecision:d=>decisions.push(d.reason),verbose:true});console.log('full sync:',JSON.stringify({wallMs:performance.now()-t,decisions,result}));
 await graph.whenIdle();graph.close();await graph.whenIdle();fs.rmSync(root,{recursive:true,force:true});
})().catch(e=>{console.error(e);process.exitCode=1;});
