const cp=require('node:child_process');
const checkout=process.argv[2],root=process.argv[3],rounds=Number(process.argv[4]||7);
for(let round=-1;round<rounds;round++)for(const mode of (round%2===0?['default','native']:['native','default'])){
 const env={...process.env};delete env.CODEGRAPH_GIT_REALPATH;if(mode==='native')env.CODEGRAPH_GIT_REALPATH='native';
 const start=performance.now();const result=cp.spawnSync(process.execPath,['--liftoff-only',checkout+'/dist/bin/codegraph.js','sync',root],{encoding:'utf8',env,timeout:60000});
 console.log(JSON.stringify({round,mode,wallMs:performance.now()-start,status:result.status,stdout:result.stdout,stderr:result.stderr}));
 if(result.status!==0)process.exit(1);
}
