const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process');
process.execArgv=['--liftoff-only'];
(async()=>{
const {CodeGraph}=require(path.join(process.argv[2]||'/workspace/codeg-fix','dist'));
const root=process.argv[3]||'/workspace/noop-major-fixture';fs.mkdirSync(root);cp.execFileSync('git',['init','-q'],{cwd:root});
for(let i=0;i<14253;i++){const dir=path.join(root,'src','subsystem_'+(i%39),'component_'+(Math.floor(i/39)%11),'internal','module');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'unit_'+i+'.c'),`int symbol_${i}(void){return ${i};}\nint call_${i}(void){return symbol_${i}();}\n`);}
cp.execFileSync('git',['add','.'],{cwd:root});
const graph=await CodeGraph.init(root,{index:true});fs.writeFileSync(path.join(root,'tracked.json'),JSON.stringify(graph.getFiles()));console.log(JSON.stringify({root,files:graph.getFiles().length,nodes:graph.getStats()}));await graph.whenIdle();graph.close();await graph.whenIdle();
})().catch(e=>{console.error(e);process.exitCode=1;});
