const cp=require('node:child_process'),fs=require('node:fs');
const root=process.argv[5]||'/workspace/noop-major-fixture';
const checkouts={base:process.argv[3]||'/workspace/codeg-planning-base',candidate:process.argv[4]||'/workspace/codeg-fix'};
const rounds=Number(process.argv[2]||5),results=[];
for(let round=-1;round<rounds;round++)for(const label of (round%2===0?['base','candidate']:['candidate','base'])){
 const started=performance.now();const result=cp.spawnSync(process.execPath,['--liftoff-only',checkouts[label]+'/dist/bin/codegraph.js','sync',root],{encoding:'utf8',env:{...process.env,CODEGRAPH_FIXED_PATH:'1'},timeout:60000});
 const entry={round,label,wallMs:performance.now()-started,status:result.status,stdout:result.stdout,stderr:result.stderr};results.push(entry);console.log(JSON.stringify(entry));
 if(result.status!==0)process.exit(1);
}
