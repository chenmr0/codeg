const fs=require('node:fs'),path=require('node:path'),{performance}=require('node:perf_hooks'),workers=require('node:worker_threads');
process.execArgv=['--liftoff-only'];
const checkout=process.argv[2],root=process.argv[3],trace=process.argv[4];
fs.writeFileSync(trace,'');const log=e=>fs.appendFileSync(trace,JSON.stringify(e)+'\n');
const OriginalWorker=workers.Worker;let sequence=0;
workers.Worker=class extends OriginalWorker{
 constructor(script,options={}){
  const id=++sequence,start=performance.now(),name=path.basename(String(script));
  if(!['scan-worker.js','rebuild-validation-worker.js'].includes(name)){super(script,options);return;}
  const code=`const fs=require('fs'),path=require('path'),{performance}=require('perf_hooks');
  const log=e=>fs.appendFileSync(${JSON.stringify(trace)},JSON.stringify({worker:${id},...e})+'\\n');
  const wrap=(o,name)=>{const fn=o[name];o[name]=function(...args){const start=performance.now();try{const result=fn.apply(this,args);if(result?.then)return result.finally(()=>log({phase:name,ms:performance.now()-start}));log({phase:name,ms:performance.now()-start});return result;}catch(e){log({phase:name,ms:performance.now()-start,error:String(e)});throw e;}};};
  const load=performance.now();const extraction=require(${JSON.stringify(path.join(checkout,'dist/extraction'))});
  const planner=require(${JSON.stringify(path.join(checkout,'dist/sync/adaptive-plan'))});
  const {QueryBuilder}=require(${JSON.stringify(path.join(checkout,'dist/db/queries'))});
  log({phase:'module-load',ms:performance.now()-load});
  for(const method of ['scanDirectory','scanDirectoryAsync'])wrap(extraction,method);
  for(const method of ['createAdaptivePlan','createAdaptivePlanOrUnchanged'])wrap(planner,method);
  wrap(QueryBuilder.prototype,'getAllFiles');
  require(${JSON.stringify(String(script))});`;
  super(code,{...options,eval:true});log({worker:id,phase:'start',name});
  this.once('exit',code=>log({worker:id,phase:'worker-exit',name,code,ms:performance.now()-start}));
 }
};
(async()=>{const start=performance.now();const {CodeGraph}=require(path.join(checkout,'dist'));log({phase:'main-module-load',ms:performance.now()-start});const opened=performance.now();const graph=CodeGraph.openSync(root);log({phase:'open',ms:performance.now()-opened});const sync=performance.now();const result=await graph.sync({verbose:true});log({phase:'sync',ms:performance.now()-sync,complete:result.complete,filesChecked:result.filesChecked,filesAdded:result.filesAdded,filesModified:result.filesModified,filesRemoved:result.filesRemoved});await graph.whenIdle();graph.close();await graph.whenIdle();})();
