const {DatabaseSync}=require('node:sqlite'),crypto=require('node:crypto'),path=require('node:path');
const root=process.argv[2];const db=new DatabaseSync(path.join(root,'.codegraph-wx','codegraph.db'),{readOnly:true});
const result={};for(const table of ['files','nodes','edges','unresolved_refs']){
const rows=db.prepare('SELECT * FROM '+table).all().map(row=>JSON.stringify(row)).sort();
result[table]={count:rows.length,sha256:crypto.createHash('sha256').update(rows.join('\n')).digest('hex')};
}
result.integrity=db.prepare('PRAGMA integrity_check').all();result.foreignKeys=db.prepare('PRAGMA foreign_key_check').all();
console.log(JSON.stringify(result));db.close();
