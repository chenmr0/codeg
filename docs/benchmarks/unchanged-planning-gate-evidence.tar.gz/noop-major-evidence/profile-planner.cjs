const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),cp=require('node:child_process');
const checkout=process.argv[2], root=process.argv[3];
(async()=>{
const planner=require(path.join(checkout,'dist/sync/adaptive-plan'));
const tracked=JSON.parse(fs.readFileSync(path.join(root,'tracked.json')));
const config=planner.adaptiveConfigFingerprint(root,tracked);
const counters={};
for(const method of ['realpathSync','lstatSync','statSync','readFileSync']){
const orig=fs[method];const wrapped=function(...args){const t=performance.now();try{return orig.apply(fs,args);}finally{const v=counters[method]??={count:0,ms:0};v.count++;v.ms+=performance.now()-t;}};Object.assign(wrapped,orig);fs[method]=wrapped;
}
const t=performance.now();const plan=await (process.argv[4]==='gate'?planner.createAdaptivePlanOrUnchanged(root,tracked,{runtimeKey:'diagnostic'},config):planner.createAdaptivePlan(root,tracked,{runtimeKey:'diagnostic'}));
console.log(JSON.stringify({wallMs:performance.now()-t,hint:plan===undefined,files:plan?.totalFiles,changed:plan?.changedFiles,counters}));
})().catch(e=>{console.error(e);process.exitCode=1;});
