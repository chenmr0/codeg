# Rust 扫描预编译发布与自动启用

## 用户安装体验

正式包的 Windows x64 / Linux x64 目录扫描与宏上下文程序均在发布前完成各自验收，npm 安装后普通 `codegraph sync` 按场景自动选择。不需要设置开启开关，不需要 Rust/Cargo/C++ 编译工具，也不在用户机器上编译或下载 Rust。

保留此前 Node/npm 运行要求及 JavaScript 依赖安装流程：这些依赖仍通过既有 npm 镜像或离线缓存提供。内置 Rust 程序不等于把 Node 和全部 npm 依赖都打进这个单一 tgz。

- `CODEGRAPH_RUST_SCAN=0`：显式关闭，完全使用此前 TypeScript 路径。
- 未设置、空值或 `auto`：只自动采用平台、版本、SHA-256 和目标平台验收记录均匹配的程序。
- `verify`：诊断用，双跑比较，始终采用 TypeScript 清单。
- `1`：开发/验收用，允许显式尝试尚未盖验收记录的程序，但仍执行扫描协议校验和失败回退。

缺失、损坏、未验证、不可执行或场景不支持时回退 TypeScript。日志的 `nativeStatus=used` 才表示实际使用了 Rust；`nativeReason` 说明为何回退。没有跨轮源码缓存，没有更改数据库结构，不需要重新 init。

目录扫描支持 `[568]`、`[is]`、`[a-z0-9]` 等正向 ASCII 字母数字字符类，保留 `.gitignore`、`.git/info/exclude`、`.codegraphignore` 与嵌套忽略规则的既有语义。此修复需要更新原生程序，单独替换 JavaScript 不会让旧程序支持新规则。`native-parity-v3` 验收增加白名单内外字符类、嵌套规则和重新纳入规则的真实差分样例；Linux 候选仍须在 Linux 上通过验收才能自动启用。否定字符类、跨类别/逆序范围等未验证形式继续保守回退。

宏上下文使用独立门槛：Windows/Linux x64 且 C-family 候选至少 5000 个时，只有 `codegraph-macros` 的版本、源码指纹、SHA-256 和 `macro-parity-v1` 目标平台验收戳都匹配才自动运行。小上下文保持 TypeScript；特殊文件逐项回退，进程/协议错误则丢弃部分结果并由 TypeScript 完整重建。`CODEGRAPH_RUST_MACROS=0` 强制关闭，`1` 强制尝试开发候选，`verify` 双跑并采用 TypeScript。

安装脚本先检查随包程序的版本、源码指纹、SHA-256 和可执行文件格式，并在 Linux 恢复执行权限（解决 Windows 打包导致的 mode 丢失）。Windows/Linux x64 上若缺少匹配的目标平台验收记录，会自动执行已有的 `validate:rust-scan` / `validate:rust-macros` 真实差分验收：只读写独立临时样例，不扫描业务目录、不打开业务索引、不下载、不编译。只有验收通过并重新核对记录后才允许自动加速；已有匹配记录时跳过重复验收。两个组件分别处理，任一失败或超时（每个最多 60 秒）均输出原因并保留 TypeScript 回退，安装本身可以完成。

建议 `npm install -g --foreground-scripts /path/to/package.tgz` 显示验收结果。若使用 `--ignore-scripts`，自动验收和执行权限修复均不会进行，可在安装目录手动运行上述两个验收命令；安装目录需要可写以保存记录。运行时的校验与场景回退规则不变，无需重建已有索引。

## 与社区分发方案的关系

参考社区 CodeGraph 1.6.0 的 `scripts/build-kernel.sh`、`.github/workflows/release.yml`、`scripts/build-bundle.sh` 和 `scripts/pack-npm.sh`：平台矩阵预构建 → 目标平台测试 → 收集产物 → 缺失产物阻止发行 → 运行时加载/回退。

保留当前 `@sdd/codegraph-wx` 的单 tgz 安装方式，将两个 x64 程序直接装入包内，适合已有的内网分发流程；不要求安装时再拉取多个原生平台 npm 包。扫描器仍是独立进程，不为了打包迁移到 N-API，不采用社区账号/包作用域作为本包发布目标。

## 发布者流程（不是业务机器要求）

1. 在源码工作树安装开发依赖并 `npm run build`。
2. 编译对应目标：

   ```bash
   npm run build:rust-scan -- --target x86_64-pc-windows-msvc
   npm run build:rust-scan -- --target x86_64-unknown-linux-musl
   npm run build:rust-macros -- --target x86_64-pc-windows-msvc
   npm run build:rust-macros -- --target x86_64-unknown-linux-musl
   ```

   构建机需要已安装对应 Rust target。Linux 使用 Rust 随附的自包含链接库和 LLD，检查产物没有动态加载器和共享库依赖；Windows 静态链接 CRT。必须保留通用 CPU 基线，不能使用 `target-cpu=native`。

3. **在目标操作系统上**运行目录与宏相关测试，再分别运行 `npm run validate:rust-scan` 和 `npm run validate:rust-macros`。两者均只使用独立临时目录且无需编译器；只有全部通过才给各自精确 SHA 写入验收记录。重编译会清除旧记录，不能把 Windows 测试结果冒充 Linux 验收。
4. 收集两个平台的 `dist/native-scan/<platform>-x64/` 和 `dist/native-macros/<platform>-x64/`，保留二进制和 manifest.json。
5. 正式发布前运行 `npm run check:native-artifacts`，它严格要求两个程序的两平台产物齐全、源码指纹一致且分别通过验收。普通 `npm pack` 的 prepack 使用 `--allow-unvalidated`：检查四组产物、manifest、版本、源码指纹、二进制 SHA-256 和可执行文件格式，允许缺少目标平台运行验收记录；不会运行扫描器或自动填写验收记录。
6. `npm run smoke:native-package -- /path/to/package.tgz --macros`：在隔离 npm prefix 安装，再从 PATH 移除 Rust/Cargo，验证目录扫描、宏程序、增删改、空同步和真实 CLI。

`manifest.json` 的哈希用于完整性/一致性校验，不是数字签名，不能取代可信的包来源或软件供应链审查。

### 使用已有原生组件在 Windows 打包

将 `native-scan` 和 `native-macros` 两个目录放入 `dist/`，各自保留 `win32-x64/`、`linux-x64/` 下的二进制及 `manifest.json`。组件必须匹配当前包版本和 Rust 源码。安装开发依赖后直接执行：

```powershell
npm run build
npm pack
```

`build` 会保留这些原生目录，无需 Rust/Cargo，也无需设置打包环境变量。未通过目标平台运行验收的组件可以随包分发，并在目标机安装时自动验收；验收未通过时运行仍会回退 TypeScript。打包成功不代表目标平台运行验收通过。

## 自动化

`.github/workflows/rust-scan-prebuilt.yml` 提供 Windows 和 Linux 原生 runner 的构建/测试矩阵，收集产物后生成 `codegraph-prebuilt-npm` artifact，并在无 Rust/Cargo PATH 的环境安装验收。这个独立工作流只产出 artifacts，不发布 npm、不创建版本、不推送代码。

既有 Release 工作流依赖上述工作流并收集其预编译产物；x64 bundle 打包也检查产物。其他平台目前仍走 TypeScript，不宣称已经提供对应 Rust 预编译。执行既有 Release 仍会触发它原有的远程发布行为，需由维护者单独授权；本次本地开发没有触发它。

## 首次 EulerOS 验收

目标已确认：EulerOS 2.0 SP15 x86_64，glibc 2.38。本地 Windows 已能生成 Linux x64 静态候选程序，但没有 Linux/WSL/Docker，**不能只凭交叉编译成功宣称 Linux 已通过运行验收**。

发布者收集齐四组匹配的原生组件后，可直接 `npm pack` 向该机器传送候选包；无需设置 `CODEGRAPH_PACK_ALLOW_INCOMPLETE`。该历史开关仍用于显式跳过产物检查，不建议用于组件齐全的普通打包。打包不会填写 Linux 验收记录，记录由目标机安装时的真实验收生成。

在 EulerOS 使用 `npm install -g --foreground-scripts /path/to/package.tgz` 安装时会自动验收（不需要 Rust/Cargo）。需要手动重验或执行额外安装冒烟测试时：

```bash
nativePackageDir="$(npm root -g)/@sdd/codegraph-wx"
cd "$nativePackageDir"
npm run validate:rust-scan
npm run validate:rust-macros
npm run smoke:native-package -- --installed "$nativePackageDir"
```

需要安装目录可写，以保存验收记录。验收通过后，该安装无需再设置开关即可自动加速；将验证输出及两个 Linux manifest 返回发布者，后者核对二进制哈希后可组装正式包。正式包的后续用户不需要重复做发行验收。

业务仓库保持静止、备份索引后再比较 `CODEGRAPH_RUST_SCAN=verify codegraph sync -v` 与普通 `codegraph sync -v`。14 组内置检查不代替真实项目验收；复杂忽略规则、中文源码目录/文件、符号链接等仍可能触发保守回退。
